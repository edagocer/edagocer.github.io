window.addEventListener("load", function () {
  document.body.classList.add("loaded");
});

$(function() {
  $(document).tooltip();
});